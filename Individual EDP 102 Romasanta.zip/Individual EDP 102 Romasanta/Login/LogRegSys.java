import java.awt.Color;
import javax.swing.*;

public class LogRegSys{

    JFrame frame1;
    JButton btnReg;
    JButton btnLog;

    JTextField txtUsername;
    JPasswordField txtPassword;

    String savedUsername = "";
    String savedpassword = "";

    Login MyLogin;
    Register MyRegister = new Register();
    public LogRegSys(){    
        frame1 = new JFrame();
        frame1.getContentPane().setBackground(Color.WHITE);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setTitle("Account Login/Register");
        frame1.setSize(400, 350);
        frame1.setLocationRelativeTo(null);
        frame1.setLayout(null);
        JLabel lbmain1 = new JLabel("Login or Register an account.");
        lbmain1.setBounds(110, 100, 180,30);

        btnReg = new JButton("Register");
        btnReg.setBounds(80, 150, 100, 30);
        btnLog = new JButton("Login");
        btnLog.setBounds(200, 150, 100, 30);
        MyLogin = new Login(this::openMainMenu);
        btnReg.addActionListener(e -> MyRegister.RegUI());
        btnLog.addActionListener(e -> MyLogin.LogUI());
        
        frame1.add(lbmain1);
        frame1.add(btnReg);
        frame1.add(btnLog);
        frame1.setVisible(true);
    }

    private void openMainMenu() {
        frame1.dispose();
        MainMenu mainMenu = new MainMenu();
        mainMenu.showMenu();
    }

    public static void main(String []args){
    new LogRegSys();
    }

}