import java.awt.Color;
import javax.swing.*;

public class Register {
    
    JFrame frame2;
    JTextField txtUsername;
    JPasswordField txtPassword;
    JPasswordField txtconfirmpass;
    JButton btnClr;
    JButton btnReg;
    JLabel lbReg1;
    JLabel lbReg2;
    JLabel lbReg3;
    JLabel lbReg4;

    static String savedUsername = "";
    static String savedPassword = "";

    public void RegUI(){

    frame2 = new JFrame();
    frame2.getContentPane().setBackground(Color.WHITE);
    frame2.setTitle("Register");
    frame2.setSize(500, 300);
    frame2.setLocationRelativeTo(null);
    frame2.setLayout(null);
    frame2.setVisible(true);
    
    txtUsername = new JTextField("Name:");
    txtUsername.setBounds(100, 200, 50, 30);
    
    lbReg1 = new JLabel("Enter your username and Password.");
    lbReg2 = new JLabel("Userame:");
    lbReg3 = new JLabel("Password:");
    lbReg4 = new JLabel("Confirm Pass:");

    lbReg1.setBounds(120, 30, 300, 30);
    lbReg2.setBounds(40, 60, 100, 30);
    lbReg3.setBounds(40, 90, 100, 30);
    lbReg4.setBounds(40, 120, 110, 30);

    btnReg = new JButton("Register");
    btnClr = new JButton("Clear");

    btnClr.setBounds(340, 90, 100, 30);
    btnReg.setBounds(200, 200, 100, 30);


    btnReg.addActionListener(e -> RegisterConfirm());
    btnClr.addActionListener(e -> ClearInfo());

    txtUsername = new JTextField();
    txtPassword = new JPasswordField();
    txtconfirmpass = new JPasswordField();

    txtUsername.setBounds(120, 60, 200, 30);
    txtPassword.setBounds( 120,90,200,30);
    txtconfirmpass.setBounds(120, 120, 200, 30);


    frame2.add(btnReg);
    frame2.add(btnClr);
    frame2.add(txtUsername);
    frame2.add(txtPassword);
    frame2.add(txtUsername);
    frame2.add(txtconfirmpass);
    frame2.add(lbReg1);
    frame2.add(lbReg2);
    frame2.add(lbReg3);
    frame2.add(lbReg4);
 }

 private void RegisterConfirm(){
    String username = txtUsername.getText();
    String password = new String(txtPassword.getPassword());
    String confirmPassword = new String(txtconfirmpass.getPassword());

    if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
        JOptionPane.showMessageDialog(frame2, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(frame2, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }


savedUsername = username;
    savedPassword = password;

    JOptionPane.showMessageDialog(frame2, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
    frame2.dispose();
}


private void ClearInfo(){
    txtUsername.setText("");
    txtPassword.setText("");
    txtconfirmpass.setText("");
}


public String getSavedUsername() {
    return savedUsername;
}

public String getSavedPassword() {
    return savedPassword;
}
}


