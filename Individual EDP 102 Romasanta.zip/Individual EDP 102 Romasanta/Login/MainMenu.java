
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import Projects.AgeChecker;
import Projects.AgeFinder;
import Projects.Base15;
import Projects.Calculator;
import Projects.DataTypes;
import Projects.HiLow;
import Projects.LoginSystem;
import Projects.MultiplicationTable;
import Projects.NameAge;
import Projects.NumberFilter;
import Projects.ShippingCost;
import Projects.Vending;
import Projects.Welcome;

public class MainMenu extends JFrame {
    JButton btn1 = new JButton("Hello Java");
    JButton btn2 = new JButton("Name and Age");
    JButton btn3 = new JButton("Data Types");
    JButton btn4 = new JButton("Shipping costs");
    JButton btn5 = new JButton("Welcome Message");
    JButton btn6 = new JButton("Age Checker");
    JButton btn7 = new JButton("Login System");
    JButton btn8 = new JButton("Age Sorter");
    JButton btn9 = new JButton("Highest and Lowest");
    JButton btn10 = new JButton("Number Filter");
    JButton btn11 = new JButton("Monster Hunter Logistic Vending Machine");
    JButton btn12 = new JButton("Multiplication Table");
    JButton btn13 = new JButton("Grade Calculator - Base 15");
    JButton btn14 = new JButton("Calculator");
    JButton btn15 = new JButton("Logout");
    JLabel lbl1 = new JLabel("Romasanta's Java Programs:", SwingConstants.CENTER);
    JLabel lbl2 = new JLabel("Select a program to run:", SwingConstants.CENTER);

    public MainMenu() {
        super("Main Menu - Romasanta's Java Programs");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout(12, 12));

        JPanel headingPanel = new JPanel(new GridLayout(2, 1, 0, 6));
        headingPanel.add(lbl1);
        headingPanel.add(lbl2);
        add(headingPanel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(7, 2, 12, 10));
        JButton[] programButtons = {
            btn1, btn2, btn3, btn4, btn5, btn6, btn7,
            btn8, btn9, btn10, btn11, btn12, btn13, btn14
        };
        Dimension buttonSize = new Dimension(300, 42);
        for (JButton button : programButtons) {
            button.setPreferredSize(buttonSize);
            menuPanel.add(button);
        }
        add(menuPanel, BorderLayout.CENTER);

        JPanel logoutPanel = new JPanel();
        btn15.setPreferredSize(new Dimension(200, 36));
        logoutPanel.add(btn15);
        add(logoutPanel, BorderLayout.SOUTH);

        pack();
        setSize(Math.max(getWidth(), 660), Math.max(getHeight(), 500));
        setLocationRelativeTo(null);

        ActionListeners();
    }

    public void showMenu() {
        setVisible(true);
    }

    public void ActionListeners(){
        btn1.addActionListener(e -> {
            setVisible(false);
            Projects.HelloJava.showWindow(this::showMenu);
        });

        btn2.addActionListener(e->  {
            setVisible(false);
            NameAge obj = new NameAge(this::showMenu);
            obj.showWindow();
        });

        btn3.addActionListener(e -> {
            setVisible(false);
            DataTypes obj = new DataTypes(this::showMenu);
            obj.showWindow();
        });

        btn4.addActionListener(e ->{
            setVisible(false);
            ShippingCost obj = new ShippingCost(this::showMenu);
            obj.showWindow();
        });

        btn5.addActionListener(e -> {
            setVisible(false);
            Welcome obj = new Welcome(this::showMenu);
            obj.showWindow();
        });

        btn6.addActionListener(e -> {
            setVisible(false);
            AgeChecker obj = new AgeChecker(this::showMenu);
            obj.showWindow();
        });

        btn7.addActionListener(e -> {
            setVisible(false);
            LoginSystem obj = new LoginSystem(this::showMenu);
            obj.showWindow();
        });

        btn8.addActionListener(e -> {
            setVisible(false);
            AgeFinder obj = new AgeFinder(this::showMenu);
            obj.showWindow();
        });

        btn9.addActionListener(e -> {
            setVisible(false);
            HiLow obj = new HiLow(this::showMenu);
            obj.showWindow();
        });

        btn10.addActionListener(e -> {
            setVisible(false);
            NumberFilter obj = new NumberFilter(this::showMenu);
            obj.showWindow();
        });

        btn11.addActionListener(e -> {
            setVisible(false);
            Vending obj = new Vending(this::showMenu);
            obj.showWindow();
        });

        btn12.addActionListener(e -> {
            setVisible(false);
            MultiplicationTable obj = new MultiplicationTable(this::showMenu);
            obj.showWindow();
        });

        btn13.addActionListener(e -> {
            setVisible(false);
            Base15 obj = new Base15(this::showMenu);
            obj.showWindow();
        });

        btn14.addActionListener(e -> {
            setVisible(false);
            Calculator calculator = new Calculator(this::showMenu);
            calculator.showWindow();
        });

        btn15.addActionListener(e -> {
            dispose();
            new LogRegSys();
        });
    }
}
