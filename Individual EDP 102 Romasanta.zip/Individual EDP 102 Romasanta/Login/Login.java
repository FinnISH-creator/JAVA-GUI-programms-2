import javax.swing.*;
import java.awt.Color;

public class Login{

    private final Runnable onLoginSuccess;
    JFrame frame3;
    JButton btnClear;
    JButton btnLogin;
    JLabel lbLog1;
    JLabel lbLog2;
    JLabel lbLog3;
    JTextField txtuserName;
    JPasswordField txtPassword;

    public Login(Runnable onLoginSuccess) {
        this.onLoginSuccess = onLoginSuccess;
    }

    public void LogUI(){
    frame3 = new JFrame();
    frame3.getContentPane().setBackground(Color.LIGHT_GRAY);
    frame3.setTitle("Login");
    frame3.setSize(450, 300);
    frame3.setLocationRelativeTo(null);
    frame3.setLayout(null);
    frame3.setVisible(true);
    

    lbLog1 = new JLabel("Enter Username & Password");
    lbLog2 = new JLabel("Username:");
    lbLog3 = new JLabel("Password:");

    lbLog1.setBounds(130, 10, 200, 60);
    lbLog2.setBounds(20, 80, 100, 30);
    lbLog3.setBounds(20, 110, 100, 30);

    txtuserName = new JTextField("");
    txtuserName.setBounds(100, 80, 200, 30);

    txtPassword = new JPasswordField();
    txtPassword.setBounds(100, 110,200, 30);

    btnClear = new JButton("Clear");
    btnLogin = new JButton("Login");

    btnClear.setBounds(320, 100, 100, 30);
    btnLogin.setBounds(180, 200, 100, 30);

    btnClear.addActionListener(e -> clear());
    btnLogin.addActionListener(e -> ConfirmLogin());


    frame3.add(lbLog2);
    frame3.add(lbLog3);
    frame3.add(lbLog1);
    frame3.add(btnClear);
    frame3.add(btnLogin);
    frame3.add(txtPassword);
    frame3.add(txtuserName);
    
    }

    private void clear(){
        txtPassword.setText(null);
        txtuserName.setText(null);
    }

    private void ConfirmLogin(){

    String savedUser = Register.savedUsername;
    String savedPass = Register.savedPassword;

    if(txtuserName.getText().equals(savedUser) && String.valueOf(txtPassword.getPassword()).equals(savedPass)){
        JOptionPane.showMessageDialog(frame3, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
        frame3.dispose();
        onLoginSuccess.run();
    } else {
        JOptionPane.showMessageDialog(frame3, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
    }

}
}
