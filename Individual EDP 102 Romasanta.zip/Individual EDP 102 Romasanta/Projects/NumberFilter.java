package Projects;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class NumberFilter {
    private final JFrame frame;
    private final Runnable onBack;
    private final JLabel resultLabel = new JLabel("Enter numbers to filter.", JLabel.CENTER);

    public NumberFilter(Runnable onBack) {
        this.onBack = onBack;
        frame = new JFrame("Number Filter");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new BorderLayout(8, 8));

        frame.add(resultLabel, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        JButton enterButton = new JButton("Enter Numbers");
        enterButton.addActionListener(e -> enterNumbers());
        buttons.add(enterButton);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.addActionListener(e -> {
            frame.dispose();
            this.onBack.run();
        });
        buttons.add(backButton);
        frame.add(buttons, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
    }

    private void enterNumbers() {
        String sizeInput = JOptionPane.showInputDialog(frame, "How many numbers do you want to enter?");
        if (sizeInput == null) {
            return;
        }

        try {
            int size = Integer.parseInt(sizeInput.trim());
            if (size <= 0) {
                showInputError("Enter a number greater than zero.");
                return;
            }

            StringBuilder result = new StringBuilder("Result: ");
            for (int i = 0; i < size; i++) {
                String numInput = JOptionPane.showInputDialog(frame, "Enter number " + (i + 1) + ":");
                if (numInput == null) {
                    return;
                }

                int num = Integer.parseInt(numInput.trim());
                if (num == 0) {
                    break;
                }
                if (num > 0) {
                    result.append(num).append(" ");
                }
            }

            resultLabel.setText(result.toString().trim());
        } catch (NumberFormatException e) {
            showInputError("Please enter valid whole numbers.");
        }
    }

    private void showInputError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Invalid Input", JOptionPane.ERROR_MESSAGE);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new NumberFilter(() -> { }).showWindow();
    }
}
