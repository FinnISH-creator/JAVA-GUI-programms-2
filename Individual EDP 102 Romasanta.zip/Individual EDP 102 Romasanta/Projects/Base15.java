package Projects;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Base15 {
    private final JFrame frame;
    private final JLabel label = new JLabel("Calculate the average for four exams (each out of 50).", JLabel.CENTER);

    public Base15(Runnable onBack) {
        frame = new JFrame("Exam Scoring System - Base 15");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(460, 220);
        frame.setLayout(new BorderLayout(8, 8));
        frame.setLocationRelativeTo(null);

        frame.add(label, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton calculateButton = new JButton("Calculate Grade");
        calculateButton.addActionListener(e -> calculateGrade());
        buttonPanel.add(calculateButton);

        JButton btnBack = new JButton("Back to Main Menu");
        btnBack.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        buttonPanel.add(btnBack);
        frame.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void calculateGrade() {
        double total = 0;
        for (int i = 1; i <= 4; i++) {
            while (true) {
                String input = JOptionPane.showInputDialog(frame, "Input score of exam " + i + " (0-50):");
                if (input == null) {
                    return;
                }

                try {
                    double score = Double.parseDouble(input.trim());
                    if (score < 0 || score > 50) {
                        JOptionPane.showMessageDialog(
                            frame,
                            "Enter a score from 0 to 50.",
                            "Invalid Score",
                            JOptionPane.ERROR_MESSAGE
                        );
                        continue;
                    }
                    total += score;
                    break;
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(
                        frame,
                        "Please enter a valid number.",
                        "Invalid Score",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        }

        double average = total / 4;
        double base15Grade = average / 50 * 15;
        String result = String.format(
            "Total: %.2f / 200 | Average: %.2f / 50 | Base-15 grade: %.2f / 15",
            total,
            average,
            base15Grade
        );
        label.setText("<html><center>" + result.replace(" | ", "<br>") + "</center></html>");
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Base15(() -> { }).showWindow();
    }
}
