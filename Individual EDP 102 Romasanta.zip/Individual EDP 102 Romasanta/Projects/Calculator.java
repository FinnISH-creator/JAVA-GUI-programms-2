package Projects;

import javax.swing.*;
import java.awt.*;

public class Calculator {

    private final JFrame frm;
    private final JTextField display;
    private final Runnable onBack;
    private final String[] btns = {"7", "8", "9", "4", "5", "6", "1", "2", "3", "0"};
    private final String[] ops = {"+", "-", "*", "/"};

    int first = -1;
    int second = -1;
    String op = null;
    boolean done = false;

    public Calculator(Runnable onBack) {
        this.onBack = onBack;
        frm = new JFrame();
        frm.setTitle("Calculator");
        frm.setSize(420, 450);
        frm.setLocationRelativeTo(null);
        frm.setLayout(null);
        frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // display
        display = new JTextField();
        display.setBounds(20, 20, 360, 50);
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("Arial", Font.BOLD, 24));
        frm.add(display);

        // digit buttons 7-9, 4-6, 1-3, 0
        for (int i = 0; i < btns.length; i++) {
            JButton b = new JButton(btns[i]);
            int row = i / 3;
            int col = i % 3;
            b.setBounds(20 + col * 90, 90 + row * 70, 80, 60);
            b.addActionListener(e -> pressDigit(Integer.parseInt(b.getText())));
            frm.add(b);
        }

        // clear and equals beside the 0 button
        JButton clear = new JButton("C");
        clear.setBounds(110, 300, 80, 60);
        clear.addActionListener(e -> clearAll());
        frm.add(clear);

        JButton equals = new JButton("=");
        equals.setBounds(200, 300, 80, 60);
        equals.addActionListener(e -> calculate());
        frm.add(equals);

        // operator buttons
        for (int i = 0; i < ops.length; i++) {
            JButton b = new JButton(ops[i]);
            b.setBounds(300, 90 + i * 70, 80, 60);
            b.addActionListener(e -> pressOp(b.getText()));
            frm.add(b);
        }

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(100, 370, 220, 32);
        backButton.addActionListener(e -> {
            frm.dispose();
            this.onBack.run();
        });
        frm.add(backButton);
    }

    public void showWindow() {
        frm.setVisible(true);
    }

    void pressDigit(int d) {
        if (done) clearAll();
        if (op == null) {
            first = d;         
        } else {
            second = d;
        }
        updateDisplay();
    }

    void pressOp(String o) {
        if (first == -1 || done) return;  
        op = o;
        second = -1;
        updateDisplay();
    }

    void calculate() {
        if (first == -1 || op == null || second == -1 || done) return;

        double result = 0;
        switch (op) {
            case "+": result = first + second; break;
            case "-": result = first - second; break;
            case "*": result = first * second; break;
            case "/":
                if (second == 0) {
                    display.setText("Error: divide by 0");
                    done = true;
                    return;
                }
                result = (double) first / second;
                break;
        }

        String shown = (result == Math.floor(result))
                ? String.valueOf((long) result)
                : String.valueOf(result);
        display.setText(shown);
        done = true;
    }

    void updateDisplay() {
        String text = "";
        if (first != -1) text += first;
        if (op != null) text += " " + op;
        if (second != -1) text += " " + second;
        display.setText(text);
    }

    void clearAll() {
        first = -1;
        second = -1;
        op = null;
        done = false;
        display.setText("");
    }

    public static void main(String[] args) {
        new Calculator(() -> { }).showWindow();
    }
}