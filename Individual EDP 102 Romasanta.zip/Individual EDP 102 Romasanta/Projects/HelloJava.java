package Projects;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.*;


public class HelloJava {
    public static void main(String[] args) {
        showWindow(() -> { });
    }

    public static void showWindow(Runnable onBack) {
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Hello Java");
        panel.add(label);

        JFrame frame = new JFrame("Hello Java");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setSize(400, 300);
        frame.add(panel, BorderLayout.CENTER);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setPreferredSize(new Dimension(260, 32));
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
