package Projects;

import javax.swing.*;

public class ShippingCost {
    private final JFrame frame;

    public ShippingCost(Runnable onBack) {
        int itemPrice = 5;
        int shippingCost = 1;
        int sum = itemPrice + shippingCost;

        frame = new JFrame("Checkout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);

        JLabel label = new JLabel("Total cost: " + sum, JLabel.CENTER);
        label.setBounds(20, 30, 345, 30);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(120, 100, 150, 30);
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(backButton);
        frame.add(label);
    }

    public ShippingCost() {
        this(() -> { });
        showWindow();
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ShippingCost();
    }
}
