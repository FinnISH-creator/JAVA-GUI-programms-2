package Projects;
import javax.swing.*;

public class AgeChecker {
    private final JFrame frame;

    public AgeChecker(Runnable onBack) {
        frame = new JFrame("Age Checker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        

        JLabel label = new JLabel("Age Checker");
        JLabel ageLabel = new JLabel("Enter your age:");
        
        label.setBounds(150, 20, 100, 30);
        ageLabel.setBounds(50, 60, 100, 30);
        
        JTextField ageField = new JTextField();

        ageField.setBounds(150, 60, 100, 30);

     
        JButton checkButton = new JButton("Check Age");
        checkButton.setBounds(150, 100, 100, 30);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(150, 140, 150, 30);
       
        
        checkButton.addActionListener(e -> {
            String ageText = ageField.getText();
            try {
                int age = Integer.parseInt(ageText);
                if (age < 18) {
                    JOptionPane.showMessageDialog(frame, "You are a minor.");
                } else {
                    JOptionPane.showMessageDialog(frame, "You are an adult.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
            }
        });

        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });



        frame.add(ageField);
        frame.add(ageLabel);
        frame.add(label);
        frame.add(checkButton);
        frame.add(backButton);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        AgeChecker ageChecker = new AgeChecker(() -> { });
        ageChecker.showWindow();
    }
}
