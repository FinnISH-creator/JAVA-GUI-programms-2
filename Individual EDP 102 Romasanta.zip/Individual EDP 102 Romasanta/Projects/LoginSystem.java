package Projects;

import javax.swing.*;

public class LoginSystem{

    JFrame frame;
    JTextField txtUsername;
    JPasswordField txtPassword;
    JButton btnRegister;
    JButton btnLogin;

    String savedUsername = null;
    String savedPassword = null;

     

    public LoginSystem(Runnable onBack){

        frame = new JFrame();

        frame.setTitle("Login and Registration");
        frame.setSize(400, 280);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbUser = new JLabel("Username:");
        lbUser.setBounds(50, 50, 100, 30);

        JLabel lbPass = new JLabel("Password:");
        lbPass.setBounds(50, 100, 100, 30);

        txtUsername = new JTextField();
        txtUsername.setBounds(150, 50, 170, 30);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 100, 170, 30);

        btnRegister = new JButton("Register");
        btnRegister.setBounds(70, 160, 110, 35);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(200, 160, 110, 35);
        

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(120, 210, 150, 30);
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
       
        
    
        btnLogin.addActionListener(e -> login());
        btnRegister.addActionListener(e -> register());
        frame.add(btnRegister);
        frame.add(btnLogin);
        frame.add(backButton);
        frame.add(lbPass);
        frame.add(lbUser);
        frame.add(txtPassword);
        frame.add(txtUsername);
        frame.setLocationRelativeTo(null);

    }

    public static void main(String []args){
      new LoginSystem(() -> {}).showWindow();
    }

    public void showWindow() {
        frame.setVisible(true);
    }
    
     private void register(){
        savedUsername = txtUsername.getText();
        savedPassword = new String(txtPassword.getPassword());

        if(savedUsername.isEmpty() || savedPassword.isEmpty()){
        JOptionPane.showMessageDialog(frame, "Fill out all fields");
        }
        JOptionPane.showMessageDialog(frame,"Registration Complete.");
    

        txtUsername.setText("");
        txtPassword.setText("");
    }

        private void login(){

        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        if(username.equals(savedUsername) && password.equals(savedPassword)){

            JOptionPane.showMessageDialog(frame, "Login Succesful");
        }
        else{   
            JOptionPane.showMessageDialog(frame, "Invalid username or password");
        }
    }
    }
