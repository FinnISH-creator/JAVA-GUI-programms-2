package Projects;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Vending {
    private final JFrame frame;
    private final Runnable onBack;
    private final JLabel label = new JLabel("Select an Item for your Hunt:", JLabel.CENTER);
    private final String[] items = {"Astrera Jarky", "ArmorSkin potion", "Potion", "Dash Juice", "Demon Drug"};
    private final double[] prices = {244, 200, 105, 112, 200};

    public Vending(Runnable onBack) {
        this.onBack = onBack;
        frame = new JFrame("Vending Machine");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new BorderLayout(8, 8));
        frame.add(label, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        JButton buyButton = new JButton("Select Item");
        buyButton.addActionListener(e -> buyItem());
        buttons.add(buyButton);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.addActionListener(e -> {
            frame.dispose();
            this.onBack.run();
        });
        buttons.add(backButton);
        frame.add(buttons, BorderLayout.SOUTH);
        frame.setLocationRelativeTo(null);
    }

    private void buyItem() {
        StringBuilder menu = new StringBuilder("--- Vending Machine ---\n");
        for (int i = 0; i < items.length; i++) {
            menu.append(i + 1).append(". ").append(items[i])
                .append(" - z").append(String.format("%.2f", prices[i])).append("\n");
        }

        String choiceInput = JOptionPane.showInputDialog(frame, menu.append("\nChoose a number:").toString());
        if (choiceInput == null) {
            return;
        }

        try {
            int index = Integer.parseInt(choiceInput.trim()) - 1;
            if (index < 0 || index >= items.length) {
                showInputError("Invalid selection.");
                return;
            }

            String moneyInput = JOptionPane.showInputDialog(
                frame,
                "Item selected: " + items[index] + " (z" + String.format("%.2f", prices[index]) + ")\nInsert money (z):"
            );
            if (moneyInput == null) {
                return;
            }

            double money = Double.parseDouble(moneyInput.trim());
            if (money >= prices[index]) {
                double change = money - prices[index];
                label.setText("Enjoy your " + items[index] + "!");
                JOptionPane.showMessageDialog(
                    frame,
                    "Dispensing " + items[index] + ". Your change is: z" + String.format("%.2f", change)
                );
            } else {
                label.setText("Transaction cancelled.");
                JOptionPane.showMessageDialog(frame, "Not enough zennies. Transaction cancelled.");
            }
        } catch (NumberFormatException e) {
            showInputError("Please enter valid numeric values.");
        }
    }

    private void showInputError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Invalid Input", JOptionPane.ERROR_MESSAGE);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Vending(() -> { }).showWindow();
    }
}
