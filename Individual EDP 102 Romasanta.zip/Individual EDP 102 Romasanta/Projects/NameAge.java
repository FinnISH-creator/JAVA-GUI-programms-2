package Projects;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class NameAge {
    private final String name = "Matt Andrue N. Romasanta";
    private final int age = 20;
    private final JFrame frame;

    public NameAge(Runnable onBack) {
        frame = new JFrame("Name and Age");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 330);

        JLabel nameLabel = new JLabel("Name: " + name, SwingConstants.CENTER);
        JLabel ageLabel = new JLabel("Age: " + age, SwingConstants.CENTER);

        nameLabel.setFont(nameLabel.getFont().deriveFont(20f));
        ageLabel.setFont(ageLabel.getFont().deriveFont(20f));

        JPanel labels = new JPanel(new GridLayout(2, 1));
        labels.add(nameLabel);
        labels.add(ageLabel);
        frame.add(labels, BorderLayout.CENTER);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setPreferredSize(new Dimension(260, 32));
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
    }

    public NameAge() {
        this(() -> { });
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            NameAge nameAge = new NameAge();
            nameAge.showWindow();
        });
    }
}
