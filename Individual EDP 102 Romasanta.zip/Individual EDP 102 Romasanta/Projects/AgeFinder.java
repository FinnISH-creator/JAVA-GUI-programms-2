package Projects;

import java.awt.GridLayout;
import javax.swing.*;

public class AgeFinder {
    private final JFrame frame;
    private final JTextField[] ageFields = new JTextField[5];
    private final JLabel resultLabel = new JLabel("Lowest age: -");

    public AgeFinder(Runnable onBack) {
        frame = new JFrame("Age Finder");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 350);
        frame.setLayout(new GridLayout(7, 2, 8, 8));

        for (int i = 0; i < ageFields.length; i++) {
            frame.add(new JLabel("Age " + (i + 1) + ":"));
            ageFields[i] = new JTextField();
            frame.add(ageFields[i]);
        }

        JButton findButton = new JButton("Find Lowest");
        findButton.addActionListener(e -> findLowestAge());
        frame.add(findButton);
        frame.add(resultLabel);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(backButton);

        frame.setLocationRelativeTo(null);
    }

    private void findLowestAge() {
        int[] ages = new int[ageFields.length];

        try {
            for (int i = 0; i < ageFields.length; i++) {
                ages[i] = Integer.parseInt(ageFields[i].getText().trim());
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                frame,
                "Please enter a whole number for each age.",
                "Invalid Age",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        int lowestAge = ages[0];
        for (int i = 1; i < ages.length; i++) {
            if (ages[i] < lowestAge) {
                lowestAge = ages[i];
            }
        }

        resultLabel.setText("Lowest age: " + lowestAge);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        AgeFinder ageFinder = new AgeFinder(() -> { });
        ageFinder.showWindow();
    }
}
