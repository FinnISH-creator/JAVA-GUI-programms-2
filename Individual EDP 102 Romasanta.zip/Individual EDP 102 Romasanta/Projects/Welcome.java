package Projects;

import javax.swing.*;

public class Welcome {

    private final JFrame frame;

    public Welcome(Runnable onBack) {
        frame = new JFrame("Welcome");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);

        JLabel label = new JLabel("Welcome to the Project!");
        label.setBounds(100, 50, 200, 30);
        frame.add(label);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(120, 150, 150, 30);
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(backButton);
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
