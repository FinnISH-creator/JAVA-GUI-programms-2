package Projects;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class HiLow {
    private final JFrame frame;

    public HiLow(Runnable onBack) {
        frame = new JFrame("Highest and Lowest Ages");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 12, 24));

        JButton sortButton = new JButton("Sort Ages");
        sortButton.setPreferredSize(new Dimension(180, 32));
        sortButton.addActionListener(e -> enterAndSortAges());
        frame.add(sortButton);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setPreferredSize(new Dimension(180, 32));
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(backButton);

        frame.setSize(420, 120);
        frame.setLocationRelativeTo(null);
    }

    private void enterAndSortAges() {
        Integer count = requestInteger("How many ages will you enter? (At least 5)");
        if (count == null) {
            return;
        }
        if (count < 5) {
            showInputError("Please enter at least five ages.");
            return;
        }

        int[] ages = new int[count];
        for (int i = 0; i < ages.length; i++) {
            Integer age = requestInteger("Enter age " + (i + 1) + " of " + count + ":");
            if (age == null) {
                return;
            }
            ages[i] = age;
        }

        Arrays.sort(ages);
        showResults(ages);
    }

    private Integer requestInteger(String prompt) {
        while (true) {
            String input = JOptionPane.showInputDialog(frame, prompt);
            if (input == null) {
                return null;
            }

            try {
                return Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                showInputError("Please enter a whole number.");
            }
        }
    }

    private void showResults(int[] sortedAges) {
        JPanel resultPanel = new JPanel(new java.awt.GridLayout(3, 1, 8, 8));
        resultPanel.add(new JLabel("Sorted ages: " + Arrays.toString(sortedAges)));
        resultPanel.add(new JLabel("Lowest age: " + sortedAges[0]));
        resultPanel.add(new JLabel("Highest age: " + sortedAges[sortedAges.length - 1]));

        JOptionPane.showMessageDialog(
            frame,
            resultPanel,
            "Age Results",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void showInputError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Invalid Input", JOptionPane.ERROR_MESSAGE);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new HiLow(() -> { }).showWindow();
    }
}
