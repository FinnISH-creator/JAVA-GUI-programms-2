package Projects;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class MultiplicationTable {
    private final JFrame frame;

    public MultiplicationTable(Runnable onBack) {
        int[][] num = new int[21][21];
        StringBuilder result = new StringBuilder("<html><body style='font-family: monospace; padding: 10px;'>");

        for (int i = 1; i <= 20; i++) {
            for (int j = 1; j <= 20; j++) {
                num[i][j] = i * j;
                String formatStr = String.format("%d×%d=%-3d ", i, j, num[i][j]);
                result.append(formatStr.replace(" ", "&nbsp;"));
            }
            result.append("<br>");
        }
        result.append("</body></html>");

        frame = new JFrame("Multiplication Table Grid");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1200, 560);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);

        JLabel label = new JLabel(result.toString());
        frame.add(new JScrollPane(label), BorderLayout.CENTER);

        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(btnBack, BorderLayout.SOUTH);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new MultiplicationTable(() -> { }).showWindow();
    }
}
