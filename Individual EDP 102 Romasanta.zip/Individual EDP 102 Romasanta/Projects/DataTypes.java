package Projects;

import javax.swing.*;

public class DataTypes {
    private final JFrame frame;

    public DataTypes(Runnable onBack) {
        int num1 = 10;
        double num2 = 20.5;
        String str = "Hello, World!";
        float num3 = 30.5f;
        boolean isTrue = true;
        char letter = 'A';

        frame = new JFrame("Data Types");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel label1 = new JLabel("Integer: " + num1);
        label1.setBounds(50, 30, 300, 30);
        JLabel label2 = new JLabel("Double: " + num2);
        label2.setBounds(50, 70, 300, 30);
        JLabel label3 = new JLabel("String: " + str);
        label3.setBounds(50, 110, 300, 30);
        JLabel label4 = new JLabel("Float: " + num3);
        label4.setBounds(50, 150, 300, 30);
        JLabel label5 = new JLabel("Boolean: " + isTrue);
        label5.setBounds(50, 190, 300, 30);
        JLabel label6 = new JLabel("Character: " + letter);
        label6.setBounds(50, 230, 300, 30);

        frame.add(label1);
        frame.add(label2);
        frame.add(label3);
        frame.add(label4);
        frame.add(label5);
        frame.add(label6);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setBounds(150, 280, 200, 30);
        backButton.addActionListener(e -> {
            frame.dispose();
            onBack.run();
        });
        frame.add(backButton);

        frame.setLocationRelativeTo(null);
    }

    public void showWindow() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        DataTypes dataTypes = new DataTypes(() -> { });
        dataTypes.showWindow();
    }
}
